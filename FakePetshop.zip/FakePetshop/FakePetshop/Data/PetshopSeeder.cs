﻿using FakePetshop.Data.Entities;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FakePetshop.Data
{
    public class PetshopSeeder
    {
        private readonly PetshopContext _context;
        private readonly IHostingEnvironment _hosting;

        public PetshopSeeder(PetshopContext context, IHostingEnvironment hosting)
        {
            _context = context;
            _hosting = hosting;
        }

        public void Seed()
        {
            _context.Database.EnsureCreated();//Create the db IF it does not already exist.

            if (!_context.Products.Any())//If no products in the db...
            {
                //Create sample data.
                var filepath = Path.Combine(_hosting.ContentRootPath, "Data/pets.json");
                var json = File.ReadAllText(filepath);

                var products = JsonConvert.DeserializeObject<IEnumerable<Product>>(json);

                _context.Products.AddRange(products);

                var order = _context.Orders.Where(o => o.Id == 1).FirstOrDefault();
                if(order != null)
                {
                    order.Items = new List<OrderItem>()
                    {
                        new OrderItem()
                        {
                            Product = products.First(),
                            Quantity = 5,
                            UnitPrice = products.First().Price
                        }
                    };
                        
                }
                _context.SaveChanges();
            }
        }

    }
}
