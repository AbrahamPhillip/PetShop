﻿using FakePetshop.Data.Entities;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FakePetshop.Data
{
    public class PetshopRepository : IPetshopRepository
    {
        private readonly PetshopContext _ctx;
        private readonly ILogger<PetshopRepository> _logger;

        public PetshopRepository(PetshopContext ctx, ILogger<PetshopRepository> logger)
        {
            _ctx = ctx;
            _logger = logger;
        }

        public IEnumerable<Product> GetAllProducts()
        {
            try
            {
                _logger.LogInformation("GetAllProducts was called.");

                return _ctx.Products.OrderBy(p => p.PetType).ToList();
            }
            catch(Exception ex)
            {
                _logger.LogError($"Failed to get all products: {ex}");
                return null;
            }
        }

        public IEnumerable<Product> GetProductsByCategory(string category)
        {
            try
            {
                _logger.LogInformation("GetProductsBycategory was called.");
                return _ctx.Products.Where(p => p.Category == category).ToList();
            }
            catch(Exception ex)
            {
                _logger.LogError($"Failed to get products by category: {ex}");
                return null;
            }
        }

        public bool SaveAll()
        {            
            try
            {
                _logger.LogInformation("SaveAll was called.");

                //SaveChanges() returns the number of rows affected.
                return _ctx.SaveChanges() > 0;//True if changes affect more than 0 rows.
            }
            catch(Exception ex)
            {
                _logger.LogError($"Failed to save all: {ex}");
                return false;
            }
        }
    }
}
