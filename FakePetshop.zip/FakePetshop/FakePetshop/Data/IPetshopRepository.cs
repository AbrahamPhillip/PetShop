﻿using System.Collections.Generic;
using FakePetshop.Data.Entities;

namespace FakePetshop.Data
{
    public interface IPetshopRepository
    {
        IEnumerable<Product> GetAllProducts();
        IEnumerable<Product> GetProductsByCategory(string category);
        bool SaveAll();
    }
}