﻿using FakePetshop.Data;
using FakePetshop.Services;
using FakePetshop.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FakePetshop.controllers
{
    public class PetController : Controller
    {
        private readonly IMailService _mailService;
        private readonly PetshopContext _context;

        public PetController(IMailService mailService, PetshopContext context)
        {
            _mailService = mailService;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("contact")]
        public IActionResult Contact()
        {
            return View();
        }

        [HttpPost("contact")]
        public IActionResult Contact(ContactViewModel model)
        {
            if (ModelState.IsValid)//Check data is valid according to the helpertags used in the model.
            {
                //Send the email.
                _mailService.SendMessage("someone@thatplace.com", model.Subject, $"From: {model.Name} - {model.Email}, Message: {model.Message}");

                //Tell user the mail has been sent.
                ViewBag.UserMessage = "Mail Sent.";

                //Clear the form.
                ModelState.Clear();
            }

            return View();
        }

        [HttpGet("about")]
        public IActionResult About()
        {
            return View();
        }

        //Display a page of products on a shoping page.
        public IActionResult Shop()
        {
            var results = from p in _context.Products
                          orderby p.Category
                          select p;

            return View(results.ToList());
        }
    }
}
