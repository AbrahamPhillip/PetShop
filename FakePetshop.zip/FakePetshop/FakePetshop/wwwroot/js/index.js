﻿$(document).ready(function () {//Code will only load AFTER the document(page) is ready. Also helps with global scope variables problems.

    /*
     * This is now using jquery. ($ means jquery)
     * As in css, use # for ids and . for classes.
     */
    
    // This is a bit of jquery to query the form.  This returns a collection...
    //var theForm = $("#theForm");//id=theForm
    //theForm.hide();

var button = $("#buyButton");//More jquery

button.on("click", function () { console.log("Adding Pet to cart") });//jquery (replaces addEventListener).
    
    //Get list items inside the product groups.
    var productInfo = $(".product-props li");//.because this is a class.  (# was for id)

    productInfo.on("click", function () {
        console.log("You clicked on " + $(this).text());// $(this) is the jquery for the item clicked on.
    });

    var $loginToggle = $("#loginToggle");
    var $popupForm = $(".popup-form");

    $loginToggle.on("click", function () {
        $popupForm.fadeToggle(700);//Show if hiddden. Hide if showing.  The number is an optional fade time.
    });
});